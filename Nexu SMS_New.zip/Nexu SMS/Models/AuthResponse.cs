﻿

namespace Nexu_SMS.Models
{
    public class AuthResponse
    {
        public string userName {  get; set; }
        public string userId { get; set; }
        public string role { get; set; }
        public string token { get; set; }
       
    }
}
