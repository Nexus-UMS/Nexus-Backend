﻿namespace Nexu_SMS.Models
{
    public class Login
    {
        public string userName { get; set; }
        public string password { get; set; }
    }
}
